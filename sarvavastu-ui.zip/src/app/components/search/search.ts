export interface Book {
    id: number;
    name: string;
    writer: string
}