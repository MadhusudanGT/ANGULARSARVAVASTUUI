import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-phone-example',
  templateUrl: './dialog-phone-example.component.html',
  styleUrls: ['./dialog-phone-example.component.css']
})
export class DialogPhoneExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
